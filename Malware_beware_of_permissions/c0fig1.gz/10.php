<?php
ignore_user_abort(true);
set_time_limit(0);
@ini_set('error_log',NULL);
@ini_set('log_errors',0);

require_once('mcurl.class.php');
function read_file($file_name)
{
	$list = dirname(__FILE__)."/"."$file_name";
	if (file_exists("$file_name") and (filesize("$file_name")>1))
	{
		$file = fopen($list,"rt");
		$arr_file = explode("\n",fread($file,filesize($list)));
		fclose($file);
		return $arr_file;
	}
	else
	{
		$arr_file = array();
		return $arr_file;
	}
}

$script_name = $_SERVER['SCRIPT_FILENAME'];
$path = strrchr($script_name, '/');

$script_name = str_replace('/', "", $path);
$script_name = str_replace('php', 'txt', $script_name);

$all_domains = read_file($script_name);

$domains_for_work = $all_domains;

$urls = array ();
for ( $u=0; $u < 15; $u++ )
{
	$domains_for_work[$u] = trim($domains_for_work[$u]);
	if (($domains_for_work[$u] != '') and ($domains_for_work[$u] != ' ') and ($domains_for_work[$u] != null))
		$urls[] = trim($domains_for_work[$u]);
}


$mcurl = new MCurl();
$mcurl->setTimeout(30);
$mcurl->setUrls($urls);
$mcurl->scan();
$content = $mcurl->getResults();

$finish_result = array();

for ($i = 0; $i < count($content); $i++)
{
	$finish_result[$i]['url'] = $urls[$i];
	$finish_result[$i]['content'] = $content[$i];
}

$check = "rvf";
$bj = fopen ("bad_list.txt", "a");
fwrite($bj, $check."\n");

$gj = fopen ("good_list.txt", "a");
fwrite($gj, $check."\n");

$nl = fopen ("not_loading.txt", "a");
fwrite($nl, $check."\n");



for ($a = 0; $a < count($finish_result); $a++)
{
	$result = $finish_result[$a]['url'];
	
	if (($finish_result[$a]['content'] == '') or ($finish_result[$a]['content'] == null) or ($finish_result[$a]['content'] == ' '))
		fwrite($nl, $result."\n");
	else
	{	
			//$status2 = stristr($finish_result[$a]['content'], 'name="_"');
			//$status8 = stristr($finish_result[$a]['content'], 'BOFF 1.0');
			//$status11 = stristr($finish_result[$a]['content'], 'islamicshell');
			//$status12 = stristr($finish_result[$a]['content'], ':: Make File ::');
			
			//$status14 = stristr($finish_result[$a]['content'], 'name="_f__f"');
			//$status15 = stristr($finish_result[$a]['content'], 'name="MTQMTUNDQOGI" value=');
			
			//////////////////////////////////////////////////////////////////////////////////////
			$with_pass_wso_1 = stristr($finish_result[$a]['content'], '<input type=password name=pass><input type=submit value=');
			
			$with_pass_unknown_1 = stristr($finish_result[$a]['content'], "<h1>Moshkela Hacker</h1> <br>
	<br><input type='text' name='user'>");
			
			$without_pass_wso_1 = stristr($finish_result[$a]['content'], 'target=_blank>[exploit-db.com]</a></nobr>');
			$without_pass_wso_2 = stristr($finish_result[$a]['content'], 'Compress (tar.gz)</option>');
			$without_pass_wso_3 = stristr($finish_result[$a]['content'], 'value);return false;"><span>Make dir:</span>');
			$without_pass_wso_4 = stristr($finish_result[$a]['content'], "<span>Delete (file or dir):</span><br><input class='toolsInp'");
			
			$without_pass_4 = stristr($finish_result[$a]['content'], '<option value="delete">Delete</option>');
			$without_pass_5 = stristr($finish_result[$a]['content'], '">download</a>&nbsp;(<a href=');
			$without_pass_6 = stristr($finish_result[$a]['content'], '>delete</a> | <a href=');
			$without_pass_7 = stristr($finish_result[$a]['content'], '<center><h1>Dark Shell');
			$without_pass_8 = stristr($finish_result[$a]['content'], "&mode=create'>Create a new file</a></td>");
			$without_pass_9 = stristr($finish_result[$a]['content'], 'mode=rmdir&rm=.>Remove directory</a>');
			$without_pass_10 = stristr($finish_result[$a]['content'], 'ls">find all writable folders and files</option>');
			$without_pass_11 = stristr($finish_result[$a]['content'], 'Command execute ::</b></p></td>');
			$without_pass_12 = stristr($finish_result[$a]['content'], '<p align="left"><b>Install program:&nbsp;<font ');
			$without_pass_13 = stristr($finish_result[$a]['content'], "/<input type=hidden name=c value='");
			
			
			if ($with_pass_wso_1 !== false)
				fwrite($gj, $result." - WSO"."\n");
			elseif (($without_pass_wso_1 !== false) or ($without_pass_wso_2 !== false) or ($without_pass_wso_3 !== false) or ($without_pass_wso_4 !== false))
				fwrite($gj, $result." - without_pass_wso"."\n");
			elseif (($without_pass_4 !== false) or ($without_pass_5 !== false) or ($without_pass_6 !== false) or ($without_pass_7 !== false) or ($without_pass_8 !== false) or ($without_pass_9 !== false) or ($without_pass_10 !== false) or ($without_pass_11 !== false) or ($without_pass_12 !== false) or ($without_pass_13 !== false))
				fwrite($gj, $result." - without_pass_handmade"."\n");
			elseif ($with_pass_unknown_1 !== false)
				fwrite($gj, $result." - with pass unknown"."\n");
			
			///////////////////////////////////////////////////////////////////////////////////////
			else
				fwrite($bj, $result."\n");
	}
		
}

fclose($nl);
fclose($gj);
fclose($bj);

for ( $i=0; $i < 15; $i++ )
{
	unset($all_domains[$i]);
}
sort ($all_domains);
		
$fnew = fopen($script_name, "w");
foreach ($all_domains as $each_domains)
{
	if (($each_domains !== '') and ($each_domains !== ' ') and ($each_domains !== null))
	{
		$each_domains = trim($each_domains);
		fwrite($fnew, $each_domains."\n");
	}
}
fclose($fnew);

?>